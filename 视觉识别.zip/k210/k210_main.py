from machine import UART
from Maix import GPIO
from fpioa_manager import fm
import utime
import sensor, image, lcd, time
import KPU as kpu
import gc, sys


def lcd_show_except(e):
    import uio
    err_str = uio.StringIO()
    sys.print_exception(e, err_str)
    err_str = err_str.getvalue()
    img = image.Image(size=(224, 224))
    img.draw_string(0, 10, err_str, scale=1, color=(0xff, 0x00, 0x00))
    lcd.display(img)


class Detector:
    def __init__(self, anchors, labels=None, model_addr="/sd/m.kmodel",
                 sensor_window=(224, 224), lcd_rotation=0,
                 sensor_hmirror=False, sensor_vflip=False):
        self.labels = labels
        self.model_addr = model_addr
        self.sensor_window = sensor_window
        self.lcd_rotation = lcd_rotation
        self.sensor_hmirror = sensor_hmirror
        self.sensor_vflip = sensor_vflip

        self.object = None
        self.value = None
        self.pos = None

        self.task = kpu.load(model_addr)
        kpu.init_yolo2(self.task, 0.5, 0.3, 5, anchors)  # threshold:[0,1], nms_value: [0, 1]

    def detect_init(self):
        sensor.reset()
        sensor.set_pixformat(sensor.RGB565)
        sensor.set_framesize(sensor.QVGA)
        sensor.set_windowing(self.sensor_window)
        sensor.set_hmirror(self.sensor_hmirror)
        sensor.set_vflip(self.sensor_vflip)
        sensor.run(1)

        lcd.init(type=1)
        lcd.rotation(self.lcd_rotation)
        lcd.clear(lcd.WHITE)

        if not self.labels:
            with open('labels.txt', 'r') as f:
                exec(f.read())
        if not self.labels:
            print("no labels.txt")
            img = image.Image(size=(320, 240))
            img.draw_string(90, 110, "no labels.txt", color=(255, 0, 0), scale=2)
            lcd.display(img)
            return 1
        try:
            img = image.Image("startup.jpg")
            lcd.display(img)
        except Exception:
            img = image.Image(size=(320, 240))
            img.draw_string(90, 110, "loading model...", color=(255, 255, 255), scale=2)
            lcd.display(img)

    def detect(self):
        img = sensor.snapshot()
        t = time.ticks_ms()
        objects = kpu.run_yolo2(self.task, img)
        t = time.ticks_ms() - t
        if objects:
            for obj in objects:
                pos = obj.rect()
                self.object = obj.classid()
                self.value = obj.value()
                self.pos = pos
                img.draw_rectangle(pos)
                img.draw_string(pos[0], pos[1], "%s : %.2f" % (self.labels[self.object], self.value),
                                scale=2, color=(255, 0, 0))
        else:
            self.object = None
        img.draw_string(0, 200, "t:%dms" % (t), scale=2, color=(255, 0, 0))
        lcd.display(img)


def main():
    # 定义一个要发送的数据：10个
    send_data = [0xaa, 0x05, 0x01, 0, 0, 0, 0, 0, 0, 0]

    def Sum_Data(d):  # 求校验和的函数
        sum_num = 0
        for i in range(9):
            sum_num += d[i]
        return sum_num & 0x00ff

    def sending_data(d1: int, d2: int, d3: int, d4: int):
        send_data[1] = d1 >> 8
        send_data[2] = d1 & 0x00ff
        send_data[3] = d2 >> 8
        send_data[4] = d2 & 0x00ff
        send_data[5] = d3 >> 8
        send_data[6] = d3 & 0x00ff
        send_data[7] = d4 >> 8
        send_data[8] = d4 & 0x00ff
        send_data[9] = Sum_Data(send_data)
        for i in range(10):
            uart_A.write(str(send_data[i]))

    # 映射UART2的两个引脚
    fm.register(5, fm.fpioa.UART1_TX, force=True)
    fm.register(4, fm.fpioa.UART1_RX, force=True)
    # 初始化串口，返回调用句柄

    uart_A = UART(UART.UART1, 115200, 8, 1, 0, timeout=1000, read_buf_len=4096)

    labels = ["holes"]
    anchors = [0.57273, 0.677385, 1.87446, 2.06253, 3.33843, 5.47434, 7.88282, 3.52778, 9.77052, 9.16828]
    model_name = 'for_ht2.kmodel'
    my_read_flag = b'1'  # 接受的内容

    c = Detector(anchors=anchors, labels=labels, model_addr=model_name)
    try:
        c.detect_init()
        while True:
            c.detect()  # 开始检测
            read_str = uart_A.read()  # 一直读取单片机串口发送的数据
            if read_str == my_read_flag:  # 匹配是否符合发送数据条件
                if c.object != None:
                    # 识别到油口后发送的坐标
                    x, y = c.pos[0], c.pos[1]
                    sending_data(d1=x, d2=y, d3=0, d4=1)  # 发送的内容-
                    utime.sleep_ms(100)
                else:
                    # 没识别到东西发送的数据
                    sending_data(-1, -1, -1, -1)  # 发送的内容
                    utime.sleep_ms(100)
    except Exception as e:
        sys.print_exception(e)
        lcd_show_except(e)
    finally:
        gc.collect()


if __name__ == "__main__":
    main()
