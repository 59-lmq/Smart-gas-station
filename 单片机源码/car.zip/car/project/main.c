 /************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
//Build by HT32init V1.09.20.506Beta
//-----------------------------------------------------------------------------
#include "ht32.h"
#include "GPIO.h"
#include "SysTick.h"
#include "BFTM0.h"
#include "USART0.h"
#include "GPTM0.h"


#define L1 IN_PA3_STATE
#define R1 IN_PC10_STATE
#define L2 IN_PA2_STATE
#define R2 IN_PC0_STATE
#define M IN_PC11_STATE

void back()
{
	OUT_PA5_LOW;
	OUT_PA6_HIGH;//right
	
	OUT_PC4_HIGH;//left
	OUT_PC5_LOW;
}
void forward()
{
	OUT_PA5_HIGH;
	OUT_PA6_LOW;//right
	OUT_PC4_LOW;
	OUT_PC5_HIGH;
}


//-----------------------------------------------------------------------------
int main(void)
{
  GPIO_Configuration();
  SysTick_Configuration();
  BFTM0_Configuration();
  //USART0_Configuration();
  GPTM0_Configuration();

	OUT_PA7_HIGH;//�ߵ�ƽʹ������оƬ
	TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,30);//R����ռ�ձ�Ϊ30
	TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,30);//L
	
	//back();
	forward();
	delay_ms(500);
  while (1)
  {
			if(R1==1 && L1==1)
			{
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,30);
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,30);
				
			}
			else if(R1==0 && L1==1)
			{
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,40);
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,20);
			}
			else if(R1==1 && L1==0)
			{
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,20);
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,40);
			}
			else if(R2==0 && L2==1)
			{
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,40);
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,10);
			}
			else if(R2==1 && L2==0)
			{
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,10);
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,40);
			}
			else if(R1==0 && L1==0 && R2==0 && L2==0 && M==0)
			{
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,0);
				TM_SetCaptureCompare(HT_GPTM0,TM_CH_2,0);
			}
  }
}
