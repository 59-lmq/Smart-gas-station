 /************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
//Build by HT32init V1.09.20.506Beta
//-----------------------------------------------------------------------------
#ifndef __GPIO_H
#define __GPIO_H

#include "ht32.h"

//-----------------------------------------------------------------------------
#define IN_PB4_PORT           B
#define IN_PB4_PIN            4
#define IN_PB4_GPIO_CLK      STRCAT2(P,          IN_PB4_PORT)
#define IN_PB4_GPIO_ID       STRCAT2(GPIO_P,     IN_PB4_PORT)
#define IN_PB4_GPIO_PORT     STRCAT2(HT_GPIO,    IN_PB4_PORT)
#define IN_PB4_GPIO_PIN      STRCAT2(GPIO_PIN_,  IN_PB4_PIN)
#define IN_PB4_AFIO_MODE     (AFIO_MODE_GPIO)
#define IN_PB4_STATE         (GPIO_ReadInBit(IN_PB4_GPIO_PORT, IN_PB4_GPIO_PIN))

#define IN_PB7_PORT           B
#define IN_PB7_PIN            7
#define IN_PB7_GPIO_CLK      STRCAT2(P,          IN_PB7_PORT)
#define IN_PB7_GPIO_ID       STRCAT2(GPIO_P,     IN_PB7_PORT)
#define IN_PB7_GPIO_PORT     STRCAT2(HT_GPIO,    IN_PB7_PORT)
#define IN_PB7_GPIO_PIN      STRCAT2(GPIO_PIN_,  IN_PB7_PIN)
#define IN_PB7_AFIO_MODE     (AFIO_MODE_GPIO)
#define IN_PB7_HIGH          IN_PB7_GPIO_PORT->SRR    = IN_PB7_PIN
#define IN_PB7_LOW           IN_PB7_GPIO_PORT->RR     = IN_PB7_PIN
#define IN_PB7_STATE         (GPIO_ReadInBit(IN_PB7_GPIO_PORT, IN_PB7_GPIO_PIN))

//-----------------------------------------------------------------------------
#define OUT_PC10_PORT           C
#define OUT_PC10_PIN            10
#define OUT_PC10_GPIO_CLK      STRCAT2(P,          OUT_PC10_PORT)
#define OUT_PC10_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC10_PORT)
#define OUT_PC10_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC10_PORT)
#define OUT_PC10_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC10_PIN)
#define OUT_PC10_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC10_HIGH          OUT_PC10_GPIO_PORT->SRR    = OUT_PC10_GPIO_PIN
#define OUT_PC10_LOW           OUT_PC10_GPIO_PORT->RR     = OUT_PC10_GPIO_PIN
#define OUT_PC10_XOR           OUT_PC10_GPIO_PORT->DOUTR ^= OUT_PC10_GPIO_PIN

#define OUT_PC11_PORT           C
#define OUT_PC11_PIN            11
#define OUT_PC11_GPIO_CLK      STRCAT2(P,          OUT_PC11_PORT)
#define OUT_PC11_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC11_PORT)
#define OUT_PC11_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC11_PORT)
#define OUT_PC11_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC11_PIN)
#define OUT_PC11_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC11_HIGH          OUT_PC11_GPIO_PORT->SRR    = OUT_PC11_GPIO_PIN
#define OUT_PC11_LOW           OUT_PC11_GPIO_PORT->RR     = OUT_PC11_GPIO_PIN
#define OUT_PC11_XOR           OUT_PC11_GPIO_PORT->DOUTR ^= OUT_PC11_GPIO_PIN

#define OUT_PC12_PORT           C
#define OUT_PC12_PIN            12
#define OUT_PC12_GPIO_CLK      STRCAT2(P,          OUT_PC12_PORT)
#define OUT_PC12_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC12_PORT)
#define OUT_PC12_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC12_PORT)
#define OUT_PC12_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC12_PIN)
#define OUT_PC12_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC12_HIGH          OUT_PC12_GPIO_PORT->SRR    = OUT_PC12_GPIO_PIN
#define OUT_PC12_LOW           OUT_PC12_GPIO_PORT->RR     = OUT_PC12_GPIO_PIN
#define OUT_PC12_XOR           OUT_PC12_GPIO_PORT->DOUTR ^= OUT_PC12_GPIO_PIN

#define OUT_PC13_PORT           C
#define OUT_PC13_PIN            13
#define OUT_PC13_GPIO_CLK      STRCAT2(P,          OUT_PC13_PORT)
#define OUT_PC13_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC13_PORT)
#define OUT_PC13_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC13_PORT)
#define OUT_PC13_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC13_PIN)
#define OUT_PC13_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC13_HIGH          OUT_PC13_GPIO_PORT->SRR    = OUT_PC13_GPIO_PIN
#define OUT_PC13_LOW           OUT_PC13_GPIO_PORT->RR     = OUT_PC13_GPIO_PIN
#define OUT_PC13_XOR           OUT_PC13_GPIO_PORT->DOUTR ^= OUT_PC13_GPIO_PIN

#define OUT_PA14_PORT           A
#define OUT_PA14_PIN            14
#define OUT_PA14_GPIO_CLK      STRCAT2(P,          OUT_PA14_PORT)
#define OUT_PA14_GPIO_ID       STRCAT2(GPIO_P,     OUT_PA14_PORT)
#define OUT_PA14_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PA14_PORT)
#define OUT_PA14_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PA14_PIN)
#define OUT_PA14_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PA14_HIGH          OUT_PA14_GPIO_PORT->SRR    = OUT_PA14_GPIO_PIN
#define OUT_PA14_LOW           OUT_PA14_GPIO_PORT->RR     = OUT_PA14_GPIO_PIN
#define OUT_PA14_XOR           OUT_PA14_GPIO_PORT->DOUTR ^= OUT_PA14_GPIO_PIN

#define OUT_PA15_PORT           A
#define OUT_PA15_PIN            15
#define OUT_PA15_GPIO_CLK      STRCAT2(P,          OUT_PA15_PORT)
#define OUT_PA15_GPIO_ID       STRCAT2(GPIO_P,     OUT_PA15_PORT)
#define OUT_PA15_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PA15_PORT)
#define OUT_PA15_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PA15_PIN)
#define OUT_PA15_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PA15_HIGH          OUT_PA15_GPIO_PORT->SRR    = OUT_PA15_GPIO_PIN
#define OUT_PA15_LOW           OUT_PA15_GPIO_PORT->RR     = OUT_PA15_GPIO_PIN
#define OUT_PA15_XOR           OUT_PA15_GPIO_PORT->DOUTR ^= OUT_PA15_GPIO_PIN

#define OUT_PB2_PORT           B
#define OUT_PB2_PIN            2
#define OUT_PB2_GPIO_CLK      STRCAT2(P,          OUT_PB2_PORT)
#define OUT_PB2_GPIO_ID       STRCAT2(GPIO_P,     OUT_PB2_PORT)
#define OUT_PB2_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PB2_PORT)
#define OUT_PB2_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PB2_PIN)
#define OUT_PB2_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PB2_HIGH          OUT_PB2_GPIO_PORT->SRR    = OUT_PB2_GPIO_PIN
#define OUT_PB2_LOW           OUT_PB2_GPIO_PORT->RR     = OUT_PB2_GPIO_PIN
#define OUT_PB2_XOR           OUT_PB2_GPIO_PORT->DOUTR ^= OUT_PB2_GPIO_PIN

#define OUT_PC14_PORT           C
#define OUT_PC14_PIN            14
#define OUT_PC14_GPIO_CLK      STRCAT2(P,          OUT_PC14_PORT)
#define OUT_PC14_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC14_PORT)
#define OUT_PC14_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC14_PORT)
#define OUT_PC14_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC14_PIN)
#define OUT_PC14_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC14_HIGH          OUT_PC14_GPIO_PORT->SRR    = OUT_PC14_GPIO_PIN
#define OUT_PC14_LOW           OUT_PC14_GPIO_PORT->RR     = OUT_PC14_GPIO_PIN
#define OUT_PC14_XOR           OUT_PC14_GPIO_PORT->DOUTR ^= OUT_PC14_GPIO_PIN

#define OUT_PC1_PORT           C
#define OUT_PC1_PIN            1
#define OUT_PC1_GPIO_CLK      STRCAT2(P,          OUT_PC1_PORT)
#define OUT_PC1_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC1_PORT)
#define OUT_PC1_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC1_PORT)
#define OUT_PC1_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC1_PIN)
#define OUT_PC1_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC1_HIGH          OUT_PC1_GPIO_PORT->SRR    = OUT_PC1_GPIO_PIN
#define OUT_PC1_LOW           OUT_PC1_GPIO_PORT->RR     = OUT_PC1_GPIO_PIN
#define OUT_PC1_XOR           OUT_PC1_GPIO_PORT->DOUTR ^= OUT_PC1_GPIO_PIN

#define OUT_PC15_PORT           C
#define OUT_PC15_PIN            15
#define OUT_PC15_GPIO_CLK      STRCAT2(P,          OUT_PC15_PORT)
#define OUT_PC15_GPIO_ID       STRCAT2(GPIO_P,     OUT_PC15_PORT)
#define OUT_PC15_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PC15_PORT)
#define OUT_PC15_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PC15_PIN)
#define OUT_PC15_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PC15_HIGH          OUT_PC15_GPIO_PORT->SRR    = OUT_PC15_GPIO_PIN
#define OUT_PC15_LOW           OUT_PC15_GPIO_PORT->RR     = OUT_PC15_GPIO_PIN
#define OUT_PC15_XOR           OUT_PC15_GPIO_PORT->DOUTR ^= OUT_PC15_GPIO_PIN

#define OUT_PA0_PORT           A
#define OUT_PA0_PIN            0
#define OUT_PA0_GPIO_CLK      STRCAT2(P,          OUT_PA0_PORT)
#define OUT_PA0_GPIO_ID       STRCAT2(GPIO_P,     OUT_PA0_PORT)
#define OUT_PA0_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PA0_PORT)
#define OUT_PA0_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PA0_PIN)
#define OUT_PA0_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PA0_HIGH          OUT_PA0_GPIO_PORT->SRR    = OUT_PA0_GPIO_PIN
#define OUT_PA0_LOW           OUT_PA0_GPIO_PORT->RR     = OUT_PA0_GPIO_PIN
#define OUT_PA0_XOR           OUT_PA0_GPIO_PORT->DOUTR ^= OUT_PA0_GPIO_PIN

#define OUT_PA1_PORT           A
#define OUT_PA1_PIN            1
#define OUT_PA1_GPIO_CLK      STRCAT2(P,          OUT_PA1_PORT)
#define OUT_PA1_GPIO_ID       STRCAT2(GPIO_P,     OUT_PA1_PORT)
#define OUT_PA1_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PA1_PORT)
#define OUT_PA1_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PA1_PIN)
#define OUT_PA1_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PA1_HIGH          OUT_PA1_GPIO_PORT->SRR    = OUT_PA1_GPIO_PIN
#define OUT_PA1_LOW           OUT_PA1_GPIO_PORT->RR     = OUT_PA1_GPIO_PIN
#define OUT_PA1_XOR           OUT_PA1_GPIO_PORT->DOUTR ^= OUT_PA1_GPIO_PIN

#define OUT_PA10_PORT           A
#define OUT_PA10_PIN            10
#define OUT_PA10_GPIO_CLK      STRCAT2(P,          OUT_PA10_PORT)
#define OUT_PA10_GPIO_ID       STRCAT2(GPIO_P,     OUT_PA10_PORT)
#define OUT_PA10_GPIO_PORT     STRCAT2(HT_GPIO,    OUT_PA10_PORT)
#define OUT_PA10_GPIO_PIN      STRCAT2(GPIO_PIN_,  OUT_PA10_PIN)
#define OUT_PA10_AFIO_MODE     (AFIO_MODE_GPIO)
#define OUT_PA10_HIGH          OUT_PA10_GPIO_PORT->SRR    = OUT_PA10_GPIO_PIN
#define OUT_PA10_LOW           OUT_PA10_GPIO_PORT->RR     = OUT_PA10_GPIO_PIN
#define OUT_PA10_XOR           OUT_PA10_GPIO_PORT->DOUTR ^= OUT_PA10_GPIO_PIN

#define IN_PD1_PORT           D
#define IN_PD1_PIN            1
#define IN_PD1_GPIO_CLK      STRCAT2(P,          IN_PD1_PORT)
#define IN_PD1_GPIO_ID       STRCAT2(GPIO_P,     IN_PD1_PORT)
#define IN_PD1_GPIO_PORT     STRCAT2(HT_GPIO,    IN_PD1_PORT)
#define IN_PD1_GPIO_PIN      STRCAT2(GPIO_PIN_,  IN_PD1_PIN)
#define IN_PD1_AFIO_MODE     (AFIO_MODE_GPIO)
#define IN_PD1_STATE         (GPIO_ReadInBit(IN_PD1_GPIO_PORT, IN_PD1_GPIO_PIN))

//-----------------------------------------------------------------------------
void GPIO_Configuration(void);

#endif

