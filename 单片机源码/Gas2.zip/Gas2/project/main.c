 /************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
//Build by HT32init V1.09.20.506Beta
//-----------------------------------------------------------------------------
#include "ht32.h"
#include "GPIO.h"
#include "SysTick.h"
#include "BFTM0.h"
#include "BFTM1.h"
#include "ADC.h"
#include "USART0.h"
#include "USART1.h"
#include "I2C1.h"
#include "GPTM0.h"

#include "math.h"
#include "LCD.h"
#include "GUI.h"
#include "oled.h"
#include "arm.h"
#include "data_process.h"
#include "sensor.h"

#define ON 1
#define OFF 0

//x��-��+ y��-��+

int16_t now_x_pos,now_y_pos;
//#define DEBUG 1
uint32_t last_t=0;
uint32_t n_t=0;
float time=0;
uint8_t steady_times = 0, is_steady = 0;

void Update_Display()
{
	//17, /* Width */Font24
	//24, /* Height */
	//LCD_2IN4_WIDTH   240 //LCD width
	//LCD_2IN4_HEIGHT  320 //LCD height
	
	Paint_DrawString_EN (5,5+41, "Hum:    %",    &Font20,    WHITE,   BLACK);//ʪ��
	Paint_ClearWindows(5+17*4,5+41,5+17*6,5+41+24,WHITE);
	Paint_DrawNum(5+17*4, 5+41 ,arm_data.humidity,&Font20, WHITE,BLACK);
	
	
	Paint_DrawString_EN (5,5+24+41, "Tem:    C",    &Font20,    WHITE,   BLACK);//�¶�
	Paint_ClearWindows(5+17*4,5+41+24,5+17*6,5+41+24+24,WHITE);
	Paint_DrawNum(5+17*4, 5+24+41 ,arm_data.temperature,&Font20,WHITE,BLACK);
}

void Set_OnOFF(uint8_t state)//1300jin900chu
{
	if(state == ON)
		TM_SetCaptureCompare(HT_GPTM1,TM_CH_1,900);
	else if(state == OFF)
		TM_SetCaptureCompare(HT_GPTM1,TM_CH_1,1700);
}
uint8_t is_smoke=0;
uint8_t had_alarm = 0;
//-----------------------------------------------------------------------------
int main(void)
{
  GPIO_Configuration();
  SysTick_Configuration();
  BFTM0_Configuration();
  BFTM1_Configuration();
  ADC_Configuration();
  USART0_Configuration();
  USART1_Configuration();
//  GPTM0_Configuration();
//	GPTM1_Configuration();
	//I2C1_Configuration();
	LCD_2IN4_Init();		
	LCD_2IN4_Clear(WHITE);
	Paint_NewImage(LCD_2IN4_WIDTH,LCD_2IN4_HEIGHT, ROTATE_0, WHITE);
	Paint_SetRotate(ROTATE_90);
	Paint_DrawImage(gImage_1,150,30,100,100);
	Paint_DrawImage(gImage_2,100,130,151,51);
	Paint_DrawImage(gImage_3,0,190,317,43);
//	delay_ms(20000);
//	USART0_Send_Data("ATD19521080244;\r\n");
//	delay_ms(10000);
//		USART0_Send_Data("ATH\r\n");

//	PID_Init();
//	Arm_Init();
//	Set_OnOFF(ON);
	
  while (1)
  {	
		is_smoke = IN_PD1_STATE;


		DHT11_Read_Data(&arm_data.temperature,&arm_data.humidity);		//��ȡ��ʪ��ֵ ռ��20ms
		
		Update_Display();
		OUT_PC14_XOR;
//		OUT_PC14_LOW;
//		//OUT_PC15_LOW;
//		OUT_PC12_LOW;
		if(arm_data.temperature>=50 || IN_PD1_STATE == 0)
		{
			arm_data.smoke_alarm = 1;
		}
		else if(arm_data.temperature<50 && IN_PD1_STATE == 1)
		{
			arm_data.smoke_alarm = 0;			
			had_alarm = 0;
		}
		
		if(arm_data.smoke_alarm == 1 && had_alarm == 0)
		{
			USART0_Send_Data("ATD19521080244;\r\n");
			delay_ms(10000);
			USART0_Send_Data("ATH\r\n");
			had_alarm = 1;
		}
		//OUT_PA14_HIGH;//beep
		delay_ms(1);
		//now_t = HT_BFTM1->CNTR;
		//time = (now_t)/48000000.0;
//		#endif

  }
}
