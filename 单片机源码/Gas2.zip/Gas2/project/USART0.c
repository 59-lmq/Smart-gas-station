 /************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
//Build by HT32init V1.09.20.506Beta
//-----------------------------------------------------------------------------
#include "USART0.h"

//-----------------------------------------------------------------------------
#include "data_process.h"


//-----------------------------------------------------------------------------
void USART0_Configuration(void)
{
  USART_InitTypeDef USART_InitStruct;
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.USART0   = 1;
  CKCUClock.Bit.AFIO     = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_2, AFIO_FUN_USART_UART);  // Config AFIO mode
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_3, AFIO_FUN_USART_UART);  // Config AFIO mode
	
	GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_3, GPIO_PR_UP);

  USART_InitStruct.USART_BaudRate = 115200;
  USART_InitStruct.USART_WordLength = USART_WORDLENGTH_8B;
  USART_InitStruct.USART_StopBits = USART_STOPBITS_1;
  USART_InitStruct.USART_Parity = USART_PARITY_NO;
  USART_InitStruct.USART_Mode = USART_MODE_NORMAL;
  USART_Init(HT_USART0, &USART_InitStruct);
  USART_RxCmd(HT_USART0, ENABLE);
  USART_TxCmd(HT_USART0, ENABLE);

  //USART_IntConfig(HT_USART0, USART_INT_RXDR, ENABLE);

  //NVIC_EnableIRQ(USART0_IRQn);
 
	
	//DMA
	

  PDMACH_InitTypeDef PDMACH_InitStructure;
  CKCUClock.Bit.PDMA       = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  PDMACH_InitStructure.PDMACH_SrcAddr   = (u32)&HT_USART0->DR;
  PDMACH_InitStructure.PDMACH_DstAddr   = (u32)USR0.rx_buff;
  PDMACH_InitStructure.PDMACH_AdrMod    = SRC_ADR_FIX | DST_ADR_LIN_INC | AUTO_RELOAD;
  PDMACH_InitStructure.PDMACH_Priority  = VH_PRIO;
  PDMACH_InitStructure.PDMACH_BlkCnt    = 7;
  PDMACH_InitStructure.PDMACH_BlkLen    = 1;
  PDMACH_InitStructure.PDMACH_DataSize  = WIDTH_8BIT;
  PDMA_Config(PDMA_USART0_RX, &PDMACH_InitStructure);
  
  PDMA_IntConfig(PDMA_USART0_RX, (PDMA_INT_GE | PDMA_INT_TC), ENABLE);
  PDMA_EnaCmd(PDMA_USART0_RX, ENABLE);  

  NVIC_EnableIRQ(PDMACH0_1_IRQn);
	
	USART_PDMACmd(HT_USART0, USART_PDMAREQ_RX, ENABLE);

  PDMA_SwTrigCmd(PDMA_USART0_RX, ENABLE);
}





