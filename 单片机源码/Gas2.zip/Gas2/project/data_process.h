#ifndef __DATA_PROCESS_H
#define __DATA_PROCESS_H

#include "USART0.h"
#include "USART1.h"
#include "arm.h"


typedef struct
{
	uint8_t tx_buff[10];
	uint8_t rx_buff[10];
	int16_t rx_data[4];
	uint8_t indexs;
	uint8_t receive_correct;
}usart_data;


extern usart_data USR0;
extern usart_data USR1;

extern uint8_t move_type;

void USART0_Send_Data(uint8_t *data);
void USART1_Send_Data(int d1,int d2,int d3,int d4);

#endif


