#ifndef __ARM_H
#define __ARM_H

#include "USART0.h"
#include "SysTick.h"
#include "math.h"

#define PI 3.1415
#define L 102  //mm
#define DEVI 15	 //mm 

typedef struct 
{
	float x,y,z;
	float c;
	float arm_angle[3];
	float set_angle[4];

	uint8_t pipe_switch;//ˮ������
	uint8_t pump_switch;//ˮ�ÿ���
	
	uint8_t work_flag;
	float bus_voltage;	//��ص�ѹ
	uint8_t temperature;	//�¶�
	uint8_t humidity;			//ʪ��
	uint8_t smoke_alarm;//����������־λ
	int16_t x_pos;
	int16_t y_pos;
	int16_t x_original;
	int16_t y_original;
	uint8_t m_flag;
	uint16_t distance;
}Arm_ctrl;

typedef struct
{
	float P;
	float I;
	float D;
	
	int16_t err;
	int16_t last_err;
	int16_t err_range;
	int16_t P_Part;
	int16_t I_Part;
	int16_t D_Part;
	int16_t PID_OUT;
	uint8_t PID_MAX;
}_PID;

extern Arm_ctrl arm_data;
extern _PID pid;
extern _PID pid_H;
extern uint16_t set_t;

void PID_Init(void);
void PID_Cal(uint16_t aim_val, uint16_t now_val, _PID *p);

void Move(uint8_t move_type,uint8_t aim_i);
void Arm_Init(void);
void Arm_Reset(void);
void Set_Angle(float angle, TM_CH_Enum CHx);


#endif

