#include "arm.h"


Arm_ctrl arm_data;
_PID pid;
_PID pid_H;
uint16_t set_t = 500 + 200*90/27.0;





void PID_Init()
{
	pid.P = 0.1;
	pid.I = 0;
	pid.D = 0;
	pid.I_Part = 0;
	pid.err_range = 40;
	pid.err = 0;
	pid.last_err = 0;
	pid.PID_MAX = 15;
	pid_H.P = 0.1;
	pid_H.I = 0;
	pid_H.D =0;
	pid_H.I_Part = 0;
	pid_H.err_range = 40;
	pid_H.err = 0;
	pid_H.last_err = 0;
	pid_H.PID_MAX = 5;
}
void PID_Cal(uint16_t aim_val, uint16_t now_val, _PID *p)
{
	p->last_err = p->err;
	p->err = aim_val - now_val;
	
	if(p->err<p->err_range && p->err > -p->err_range)
	{
		p->PID_OUT = 0;
		p->P_Part = 0;
		return;
	}
	
	p->P_Part = p->P * p->err;
	p->I_Part += p->I * p->err;
	p->D_Part = p->D * (p->err - p->last_err);
	
	if(p->I_Part >30)
		p->I_Part = 30;
	else if(p->I_Part < -30)
		p->I_Part = -30;
	
	p->PID_OUT = p->P_Part + p->I_Part + p->D_Part;
	
	if(p->PID_OUT>p->PID_MAX)
		p->PID_OUT = p->PID_MAX;
	else if(p->PID_OUT<-p->PID_MAX)
		p->PID_OUT = -p->PID_MAX;
}
void Set_Angle(float angle, TM_CH_Enum CHx)
{
	u16 t;
	if(CHx == TM_CH_3 && angle < 75)
		angle = 75;
//	else if(angle<90)
//		angle = 90;
	else if(angle>270)
		angle = 270;
	t = 500 + 200*angle/27.0;
	TM_SetCaptureCompare(HT_GPTM0,CHx,t);
}
void Arm_Init()
{
	arm_data.arm_angle[0] = 52;
	arm_data.arm_angle[2] = 76;
	arm_data.arm_angle[1] = 52;
	
	arm_data.x = L*cos(arm_data.arm_angle[0]*PI/180)+L*cos(arm_data.arm_angle[1]*PI/180);
	arm_data.y = L*sin(arm_data.arm_angle[0]*PI/180)-L*sin(arm_data.arm_angle[1]*PI/180);
	arm_data.c = sqrt(arm_data.x*arm_data.x+arm_data.y*arm_data.y);
	
	arm_data.arm_angle[0] = acos(arm_data.c/2/L)*180/PI+atan(arm_data.y/arm_data.x)*180/PI;
	arm_data.arm_angle[2] = 2*asin(arm_data.c/2/L)*180/PI;
	arm_data.arm_angle[1] = 180 - arm_data.arm_angle[0] - arm_data.arm_angle[2];
	
	arm_data.set_angle[1] = arm_data.arm_angle[0] + 90;
	arm_data.set_angle[2] = arm_data.arm_angle[1] + 180;
	arm_data.set_angle[3] = arm_data.arm_angle[2];
	arm_data.set_angle[0] = 90;
	
	arm_data.x_pos = 130;//160
	arm_data.y_pos = 120;
	arm_data.x_original = 0;
	arm_data.y_original = 0;
	arm_data.distance = 0;
	
	arm_data.m_flag = 0;
	
	Set_Angle(arm_data.set_angle[0],TM_CH_0);
	Set_Angle(arm_data.set_angle[1],TM_CH_1);
	Set_Angle(arm_data.set_angle[2],TM_CH_2);
	Set_Angle(arm_data.set_angle[3],TM_CH_3);
	TM_Cmd(HT_GPTM0, ENABLE);
	
	arm_data.work_flag = 1;
}
void Move_Y(uint8_t aim_i,uint8_t move_type)
{
	uint8_t i;
	float angle_copy[3];
	float x,y,c;
	float angle_t;

	float y_max = sqrt(L*L-(arm_data.x-L)*(arm_data.x-L));
	x = arm_data.x;
	y = arm_data.y;
	c = arm_data.c;
//	for(i=0;i<aim_i;i++)
//	{
//		if(move_type == UP && arm_data.arm_angle[1] != 0)
//			angle_copy[0] += 1;
//		else if(move_type == DOWN && angle_copy[0] != 0)
//			angle_copy[0] -= 1;
//		angle_copy[1] = acos(arm_data.x-cos(angle_copy[0]*PI/180))*180/PI;
//		angle_copy[2] = 180 - angle_copy[0] - angle_copy[1];
//		if(angle_copy[2]<75)
//		{
//			angle_copy[2]=75;
//			angle_copy[1] = 180 - angle_copy[0] - angle_copy[2];
//		}
//		
//		arm_data.arm_angle[0] = angle_copy[0];
//		arm_data.arm_angle[1] = angle_copy[1];
//		arm_data.arm_angle[2] = angle_copy[2];
//		
//		arm_data.set_angle[1] = arm_data.arm_angle[0] + 90;
//		arm_data.set_angle[2] = arm_data.arm_angle[1] + 180;
//		arm_data.set_angle[3] = arm_data.arm_angle[2];
//		
//		Set_Angle(arm_data.set_angle[1],TM_CH_1);
//		Set_Angle(arm_data.set_angle[2],TM_CH_2);
//		Set_Angle(arm_data.set_angle[3],TM_CH_3);
//		delay_ms(100);
//	}
//	arm_data.y = sin(arm_data.arm_angle[0]*PI/180) - sin(arm_data.arm_angle[1]*PI/180);
	//for(i=0;i<aim_i;i++)
	{
		if(move_type == UP && y<y_max)
			y+=aim_i;
		else if(move_type == DOWN && y>(-y_max))
			y-=aim_i;
		c = sqrt(x*x+y*y);
	
//		arm_data.arm_angle[0] = acos(arm_data.c/2/L)*180/PI+atan(arm_data.y/arm_data.x)*180/PI;
//		arm_data.arm_angle[2] = 2*asin(arm_data.c/2/L)*180/PI;
//		arm_data.arm_angle[1] = 180 - arm_data.arm_angle[0] - arm_data.arm_angle[2];
		
		angle_t = atan(y/x)*180/PI;
		angle_copy[0] = acos(c/2/L)*180/PI;
		angle_copy[2] = 2*asin(c/2/L)*180/PI;
		angle_copy[1] = 180 - angle_copy[0] - angle_copy[2];
		
		if(angle_copy[2]<=76)
			return;
		else if(angle_copy[1]>=70)
			return;
		else
		{
			arm_data.arm_angle[0] = angle_copy[0];
			arm_data.arm_angle[1] = angle_copy[1];
			arm_data.arm_angle[2] = angle_copy[2];
			arm_data.x = x;
			arm_data.y = y;
			arm_data.c = c;
		}
		
		arm_data.set_angle[1] = arm_data.arm_angle[0] + 90 + angle_t;
		arm_data.set_angle[2] = arm_data.arm_angle[1] - angle_t + 180;
		arm_data.set_angle[3] = arm_data.arm_angle[2];
		
//		Set_Angle(arm_data.set_angle[1],TM_CH_1);
//		Set_Angle(arm_data.set_angle[2],TM_CH_2);
//		Set_Angle(arm_data.set_angle[3],TM_CH_3);
	}
}
void Move_X(uint8_t aim_i,uint8_t move_type)
{
	uint8_t i;
	float angle_copy[3];
	float x,y,c;
	float angle_t;
	float x_max = L + sqrt((L*L-(arm_data.y)*(arm_data.y)));
	float x_min = sqrt(2*L*cos(52*PI/180) * 2*L*cos(52*PI/180)-arm_data.y*arm_data.y);
	x = arm_data.x;
	y = arm_data.y;
	c = arm_data.c;
//	angle_copy[0] = arm_data.arm_angle[0];
//	for(i=0;i<aim_i;i++)
//	{
//		if(move_type == FORWARD && angle_copy[0] != 0 && arm_data.arm_angle[1] != 0)
//			angle_copy[0] -= 1;
//		else if(move_type == BACK && angle_copy[0] < 90)
//			angle_copy[0] += 1;
//		watch = sin(angle_copy[0]*PI/180)-arm_data.y;
//		if(watch > 1)
//			return;
//		angle_copy[1] = asin(watch)*180/PI;
//		angle_copy[2] = 180 - angle_copy[0] - angle_copy[1];
//		
//		if(angle_copy[2]<75 && move_type == BACK)
//		{
//			arm_data.arm_angle[2] = 75;
//			arm_data.arm_angle[1] = 180 - arm_data.arm_angle[0] - arm_data.arm_angle[2];
//		}
//		else
//		{
//			arm_data.arm_angle[0] = angle_copy[0];
//			arm_data.arm_angle[1] = angle_copy[1];
//			arm_data.arm_angle[2] = angle_copy[2];
//		}
//		
//		arm_data.set_angle[1] = arm_data.arm_angle[0] + 90;
//		arm_data.set_angle[2] = arm_data.arm_angle[1] + 180;
//		arm_data.set_angle[3] = arm_data.arm_angle[2];
//		
//		Set_Angle(arm_data.set_angle[1],TM_CH_1);
//		Set_Angle(arm_data.set_angle[2],TM_CH_2);
//		Set_Angle(arm_data.set_angle[3],TM_CH_3);
//		delay_ms(20);
//	}
//	arm_data.x = cos(arm_data.arm_angle[0]*PI/180) + cos(arm_data.arm_angle[1]*PI/180);
	//for(i=0;i<aim_i;i++)
	{
		if(move_type == FORWARD && x<x_max)
			x += aim_i;
		else if(move_type == BACK && x>x_min)
			x -= aim_i;
		c = sqrt(x*x+y*y);
	
		angle_t = atan(y/x)*180/PI;
		angle_copy[0] = acos(c/2/L)*180/PI;
		angle_copy[2] = 2*asin(c/2/L)*180/PI;
		angle_copy[1] = 180 - angle_copy[0] - angle_copy[2];
//		arm_data.arm_angle[0] = acos(arm_data.c/2/L)*180/PI+atan(arm_data.y/arm_data.x)*180/PI;
//		arm_data.arm_angle[2] = 2*asin(arm_data.c/2/L)*180/PI;
//		arm_data.arm_angle[1] = 180 - arm_data.arm_angle[0] - arm_data.arm_angle[2];
		if(angle_copy[2]<=76)
			return;
		else if(angle_copy[1]>=70)
			return;
		else
		{
			arm_data.arm_angle[0] = angle_copy[0];
			arm_data.arm_angle[1] = angle_copy[1];
			arm_data.arm_angle[2] = angle_copy[2];
			arm_data.x = x;
			arm_data.y = y;
			arm_data.c = c;
		}
		arm_data.set_angle[1] = arm_data.arm_angle[0] + 90 + angle_t;
		arm_data.set_angle[2] = arm_data.arm_angle[1] - angle_t + 180;
		arm_data.set_angle[3] = arm_data.arm_angle[2];
		
//		Set_Angle(arm_data.set_angle[1],TM_CH_1);
//		Set_Angle(arm_data.set_angle[2],TM_CH_2);
//		Set_Angle(arm_data.set_angle[3],TM_CH_3);
	}
}
void Move_Z(uint8_t aim_i,uint8_t move_type)
{
	uint16_t i;
//	for(i=0;i<aim_i;i++)
//	{
//		if(move_type == LEFT && arm_data.set_angle[0]<110)
//			arm_data.set_angle[0] += 1;
//		else if(move_type == RIGHT && arm_data.set_angle[0]>70)
//			arm_data.set_angle[0] -= 1;
//		
//		Set_Angle(arm_data.set_angle[0],TM_CH_0);
//		delay_ms(20);
//	}
	//for(i=0;i<aim_i;i++)
	{
		if(move_type == LEFT && set_t<1315)
			set_t += aim_i;
		else if(move_type == RIGHT && set_t>950)
			set_t -= aim_i;
//		TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,set_t);
		//delay_us(500);
	}
}
void Move(uint8_t move_type,uint8_t aim_i)
{
	if(move_type == UP || move_type == DOWN)
		Move_Y(aim_i,move_type);
	else if(move_type == FORWARD || move_type == BACK)
		Move_X(aim_i,move_type);
	else if(move_type == LEFT || move_type == RIGHT)
		Move_Z(aim_i,move_type);
}
void Arm_Reset()
{
	TM_Cmd(HT_GPTM0, ENABLE);
	Set_Angle(90,TM_CH_0);
	Set_Angle(180,TM_CH_1);
	Set_Angle(80,TM_CH_2);
	Set_Angle(270,TM_CH_3);
	arm_data.work_flag = 0;
	TM_Cmd(HT_GPTM0, DISABLE);
}


