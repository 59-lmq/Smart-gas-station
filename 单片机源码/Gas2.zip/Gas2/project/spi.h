#ifndef __SPI_H
#define __SPI_H

#include "ht32.h"
#include "GPIO.h"

#define SDA_HIGH OUT_PC12_HIGH
#define SDA_LOW  OUT_PC12_LOW
#define SCL_HIGH OUT_PC11_HIGH
#define SCL_LOW  OUT_PC11_LOW

#define RST_HIGH OUT_PA15_HIGH
#define RST_LOW  OUT_PA15_LOW
#define DC_HIGH  OUT_PC13_HIGH
#define DC_LOW   OUT_PC13_LOW
#define CS_HIGH  OUT_PC10_HIGH
#define CS_LOW   OUT_PC10_LOW

void SPI_init(void);
void SPI_Write_Data8(uint8_t data);
void SPI_Write_Data16(uint16_t data);

#endif

