#include "spi.h"

void SPI_init()
{
//	GPIO_ClearOutBits       (OUT_PA9_GPIO_PORT, OUT_PA9_GPIO_PIN);
//  GPIO_DirectionConfig    (OUT_PA9_GPIO_PORT, OUT_PA9_GPIO_PIN, GPIO_DIR_OUT);
}

void SPI_Write_Data8(uint8_t data)
{
	uint8_t i;
	for(i=0;i<8;i++)
	{
		if(data&0x80)
			SDA_HIGH;
		else 
			SDA_LOW;
		SCL_LOW;
		SCL_HIGH;
		data<<=1;
	}	 
}
void SPI_Write_Data16(uint16_t data)
{
	SPI_Write_Data8(data>>8);
	SPI_Write_Data8(data);
}


