 /************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
//Build by HT32init V1.09.20.506Beta
//-----------------------------------------------------------------------------
#include "ht32.h"
#include "GPIO.h"
#include "SysTick.h"
#include "BFTM0.h"
#include "BFTM1.h"
#include "ADC.h"
#include "USART0.h"
#include "USART1.h"
#include "I2C1.h"
#include "GPTM0.h"

#include "math.h"
#include "LCD.h"
#include "GUI.h"
#include "oled.h"
#include "arm.h"
#include "data_process.h"
#include "sensor.h"



//x��-��+ y��-��+


uint8_t steady_times = 0, is_steady = 0;



uint8_t is_ok=0;
uint16_t w=1200;
//-----------------------------------------------------------------------------
int main(void)
{
  GPIO_Configuration();
  SysTick_Configuration();
  BFTM0_Configuration();
  BFTM1_Configuration();
  ADC_Configuration();
	delay_ms(5000);//�ȴ�K210����
  USART0_Configuration();
  USART1_Configuration();
  GPTM0_Configuration();
	GPTM1_Configuration();
	//I2C1_Configuration();
	LCD_2IN4_Init();		
	LCD_2IN4_Clear(GREEN);

	PID_Init();
	Arm_Init();

  while (1)
  {	
		if(USR1.rx_data[2] == -1 && USR1.rx_data[3] == -1)
		{
			pid.PID_OUT=0;
			pid_H.PID_OUT=0;
			arm_data.m_flag = 0;
		}
		else if(arm_data.m_flag == 1)
		{
			PID_Cal(arm_data.y_pos, 120, &pid);
			PID_Cal(arm_data.x_pos, 130, &pid_H);
			
			if(pid.PID_OUT<0)//y<aim_y
			{
				Move(LEFT,-pid.PID_OUT);
			}
			else if(pid.PID_OUT>0)
			{
				Move(RIGHT,pid.PID_OUT);
			}
			if(pid_H.PID_OUT<0)
			{
				Move(DOWN,-pid_H.PID_OUT);
			}
			else if(pid_H.PID_OUT>0)
			{
				Move(UP,pid_H.PID_OUT);
			}
			//�ж��Ƿ��Ѿ��ȶ���׼�Ϳ�
			if(pid_H.PID_OUT == 0 && pid.PID_OUT ==0 && arm_data.m_flag == 1)
			{
				steady_times++;
				if(steady_times == 10)
				{
					steady_times = 0;
					is_steady = 1;
				}
				delay_ms(200);
			}
			else
			{
				steady_times = 0;
				is_steady = 0;
			}
			Set_Angle(arm_data.set_angle[1],TM_CH_1);
			Set_Angle(arm_data.set_angle[2],TM_CH_2);
			Set_Angle(arm_data.set_angle[3],TM_CH_3);
			TM_SetCaptureCompare(HT_GPTM0,TM_CH_0,set_t);
			arm_data.m_flag = 0;
		}
		if(is_steady == 1 && is_ok==0)
		{
			delay_ms(5000);
			
			//΢��
//			if(arm_data.y_pos<120 && arm_data.y_pos>100)
			Start_Oil();
			is_steady = 0;
			is_ok=0;
			delay_ms(5000);
			
		}
		//delay_ms(100);

		if(IN_PB4_STATE)//��������LED
			OUT_PC1_LOW;
		else if(!IN_PB4_STATE)
			OUT_PC1_HIGH;
		if(IN_PB2_STATE)//��������ˮ��
			OUT_PA14_HIGH;
		else if(!IN_PB2_STATE)
			OUT_PA14_LOW;
		
  }
}
