#include "data_process.h"

usart_data USR0 = {0};
usart_data USR1 = {0};

uint8_t rx;
uint8_t move_type=STOP;


uint8_t Sum_Data(uint8_t *buff)
{
	uint8_t i,sum=0;
	for(i=0;i<9;i++)
		sum += buff[i];
	return sum;
}

//USART0��ش���
void USART0_analyze_data(void)
{
//	switch(rx)
//	{
//		case 0:
//			move_type = STOP;break;
//		case 1:
//			move_type = FORWARD;break;
//		case 2:
//			move_type = BACK;break;
//		case 3:
//			move_type = LEFT;break;
//		case 4:
//			move_type = RIGHT;break;
//		case 5:
//			move_type = UP;break;
//		case 6:
//			move_type = DOWN;break;
//		case 7:
//			Arm_Init();break;
//		default:break;
//	}
	
}


void USART0_Send_Data(uint8_t *data)
{
	while(*data !='\0')
	{
		USART_SendData(HT_USART0,*data);
		while(!USART_GetFlagStatus(HT_USART0,USART_FLAG_TXC));//�ȴ��������
		data++;
	}
}
uint8_t flag=0;
void PDMA_CH0_1_IRQHandler(void)
{
  if(PDMA_GetFlagStatus(PDMA_CH0, PDMA_FLAG_TC) == SET)
  {
		if(USR0.rx_buff[0] == '1' || USR0.rx_buff[0] == '2' || USR0.rx_buff[0] == '3' || USR0.rx_buff[0] == '4')
			flag = 1;
		//arm_data.work_flag = 1;
    PDMA_ClearFlag(PDMA_CH0, PDMA_INT_GE);
  }
}


//USART1��ش���
void PDMA_CH2_5_IRQHandler(void)//usart1
{
	uint8_t i;
	uint8_t sum;
  if(PDMA_GetFlagStatus(PDMA_CH2, PDMA_FLAG_TC) == SET)
  {
    PDMA_ClearFlag(PDMA_CH2, PDMA_INT_GE);
		sum = Sum_Data(USR1.rx_buff);
		if(USR1.rx_buff[9] == sum && USR1.rx_buff[0] == 0xaa)
		{
			for(i=0;i<4;i++)
			{
				USR1.rx_data[i] = (int16_t)(USR1.rx_buff[2*i+1]<<8)|USR1.rx_buff[2*i+2];
			}

			if(USR1.rx_data[0]!=-1)
			{
//				arm_data.x_pos = USR1.rx_data[0] + USR1.rx_data[2]/2;
//				arm_data.y_pos = USR1.rx_data[1] + USR1.rx_data[3]/2;
				arm_data.x_pos = USR1.rx_data[0] + USR1.rx_data[3]/2;
				arm_data.y_pos = USR1.rx_data[1] + USR1.rx_data[2]/2;
				
				arm_data.x_original = USR1.rx_data[0];
				arm_data.y_original = USR1.rx_data[1];
			}
			arm_data.m_flag = 1;
		}
	}
}
void USART1_Send_Data(int d1,int d2,int d3,int d4)
{
	uint8_t i;
	USR1.tx_buff[1] = d1>>8;
	USR1.tx_buff[2] = d1&0x00ff;
	USR1.tx_buff[3] = d2>>8;
	USR1.tx_buff[4] = d2&0x00ff;
	USR1.tx_buff[5] = d3>>8;
	USR1.tx_buff[6] = d3&0x00ff;
	USR1.tx_buff[7] = d4>>8;
	USR1.tx_buff[8] = d4&0x00ff;
	USR1.tx_buff[9] = Sum_Data(USR1.tx_buff);
	for(i=0;i<10;i++)
	{
		USART_SendData(HT_USART1, USR1.tx_buff[i]);	
		while(!USART_GetFlagStatus(HT_USART1,USART_FLAG_TXC));
	}
}



