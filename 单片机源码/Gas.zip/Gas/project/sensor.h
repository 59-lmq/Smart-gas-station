#ifndef __SENSOR_H
#define __SENSOR_H

#include "SysTick.h"
#include "GPIO.h"
#include "oled.h"

#define I2C_DEVID 0XA4

//IO��������
#define DHT11_IO_IN()  GPIO_DirectionConfig(OUT_PA10_GPIO_PORT, OUT_PA10_GPIO_PIN, GPIO_DIR_IN)
#define DHT11_IO_OUT() GPIO_DirectionConfig(OUT_PA10_GPIO_PORT, OUT_PA10_GPIO_PIN, GPIO_DIR_OUT)

//IO��������											   
#define	DHT11_HIGH    OUT_PA10_HIGH//���ݶ˿�	PA10
#define	DHT11_LOW     OUT_PA10_LOW//���ݶ˿�	PA10

#define	DHT11_DQ_IN   (GPIO_ReadInBit(OUT_PA10_GPIO_PORT, OUT_PA10_GPIO_PIN)) //���ݶ˿�	PA10

u8 DHT11_Init(void);
u8 DHT11_Read_Data(u8 *temp,u8 *humi);


#endif

