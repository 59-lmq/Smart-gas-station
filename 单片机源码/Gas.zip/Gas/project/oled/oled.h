#ifndef __OLED_H__
#define __OLED_H__

//#include "main.h"
#include "ht32.h"
#include "GPIO.h"
////λ������,ʵ��51���Ƶ�GPIO���ƹ���
////����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).
////IO�ڲ����궨��
//#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
//#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
//#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
////IO�ڵ�ַӳ��
//#define GPIOB_ODR_Addr    (GPIOB_BASE+12) //0x40010C0C 
//#define GPIOB_IDR_Addr    (GPIOB_BASE+8) //0x40010C08 

////IO�ڲ���,ֻ�Ե�һ��IO��!
////ȷ��n��ֵС��16!

//#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
//#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

//#define IIC_SCL    PBout(11) //SCL
//#define IIC_SDA    PBout(10) //SDA

//#define SDA_GPIO_Port GPIOB
//#define SCL_GPIO_Port GPIOB
//#define SDA_PIN GPIO_PIN_10
//#define SCL_PIN GPIO_PIN_11

#define IIC_SCL_0 OUT_PA1_LOW
#define IIC_SCL_1 OUT_PA1_HIGH
#define IIC_SDA_0 OUT_PA0_LOW
#define IIC_SDA_1 OUT_PA0_HIGH

#define WIDTH 128
#define HEIGHT 64
#define PAGES 8

#define _swap_char(a, b) \
    {                    \
        uint8_t t = a;     \
        a = b;           \
        b = t;           \
    }

extern uint8_t OLEDBuff[WIDTH * PAGES];

void IIC_Start(void);
void IIC_Stop(void);
void Write_IIC_Byte(unsigned char date);
void OLED_WrDat(unsigned char IIC_Data);
void IIC_Init(void);
void OLED_Init(void);
void Clear_Buff(void);
void Draw_FullPic(unsigned char BMP[]);
void Draw_Clock(uint8_t x,uint8_t y,uint8_t r,float _angle);
void Draw_Pic(unsigned char x0, uint8_t y0,uint8_t x1, uint8_t y1,const unsigned char pic[]);
#endif







