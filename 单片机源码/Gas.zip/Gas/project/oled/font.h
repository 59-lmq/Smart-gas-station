#ifndef __FONT_H__
#define __FONT_H__

extern const unsigned char my_52X48pic[];

#endif





