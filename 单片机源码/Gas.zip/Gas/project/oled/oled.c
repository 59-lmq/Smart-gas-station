#include "oled.h"
#include "font.h"
#include "math.h"
#include "SysTick.h"

uint8_t OLEDBuff[WIDTH * PAGES];



void IIC_Init()
{
	;
}

//����IIC��ʼ�ź�
void IIC_Start(void)
{
	IIC_SDA_1;	  	  
	delay_us(1);
	IIC_SCL_1;
	delay_us(1);
 	IIC_SDA_0;//START:when CLK is high,DATA change form high to low 
	delay_us(1);
	IIC_SCL_0;//ǯסI2C���ߣ�׼�����ͻ�������� 
}	  
//����IICֹͣ�ź�
void IIC_Stop(void)
{
	IIC_SDA_0;
	delay_us(1);
	IIC_SCL_1;//STOP:when CLK is high DATA change form low to high
 	delay_us(1); 
	IIC_SDA_1;//����I2C���߽����ź�			   	
}				     
//IIC����һ���ֽ�
void Write_IIC_Byte(unsigned char date)
{
	unsigned char i, temp;
	temp = date;
			
	for(i=0; i<8; i++)
	{	
		IIC_SCL_0;
    if ((temp&0x80)==0)
			IIC_SDA_0;
    else 
			IIC_SDA_1;
		temp = temp << 1;
		delay_us(1);			  
		IIC_SCL_1;
		delay_us(1);
	}
	IIC_SCL_0;
	delay_us(1);
	IIC_SDA_1;
	delay_us(1);
	IIC_SCL_1;
	delay_us(1);
	IIC_SCL_0;
	delay_us(1);
}

/*********************OLEDд����************************************/ 
void OLED_WrDat(unsigned char IIC_Data)
{
//	I2C_TargetAddressConfig(HT_I2C1, 0x3c, I2C_MASTER_WRITE);

//  /* Check on Master Transmitter STA condition and clear it                                                 */
//  while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_SEND_START));

//  /* Check on Master Transmitter ADRS condition and clear it                                                */
//  while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_TRANSMITTER_MODE));
//  /* Send data                                                                                              */
//    /* Check on Master Transmitter TXDE condition                                                           */
//  while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_TX_EMPTY));
//    /* Master Send I2C data                                                                                 */
//	I2C_SendData(HT_I2C1, 0x40);
//	while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_TX_EMPTY));
//    /* Master Send I2C data                                                                                 */
//	I2C_SendData(HT_I2C1, IIC_Data);

//  /* Send I2C STOP condition                                                                                */
//  I2C_GenerateSTOP(HT_I2C1);
//  /*wait for BUSBUSY become idle                                                                            */
//  while (I2C_ReadRegister(HT_I2C1, I2C_REGISTER_SR)&0x80000);
	IIC_Start();
	Write_IIC_Byte(0x78);
	Write_IIC_Byte(0x40);			//write data
	Write_IIC_Byte(IIC_Data);
	IIC_Stop();
}
/*********************OLEDд����************************************/
void OLED_WrCmd(unsigned char IIC_Command)
{
//	I2C_TargetAddressConfig(HT_I2C1, 0x3c, I2C_MASTER_WRITE);

//  /* Check on Master Transmitter STA condition and clear it                                                 */
//  while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_SEND_START));

//  /* Check on Master Transmitter ADRS condition and clear it                                                */
//  while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_TRANSMITTER_MODE));
//  /* Send data                                                                                              */
//    /* Check on Master Transmitter TXDE condition                                                           */
//  while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_TX_EMPTY));
//    /* Master Send I2C data                                                                                 */
//	I2C_SendData(HT_I2C1, 0x00);
//	while (!I2C_CheckStatus(HT_I2C1, I2C_MASTER_TX_EMPTY));
//    /* Master Send I2C data                                                                                 */
//	I2C_SendData(HT_I2C1, IIC_Command);

//  /* Send I2C STOP condition                                                                                */
//  I2C_GenerateSTOP(HT_I2C1);
//  /*wait for BUSBUSY become idle                                                                            */
//  while (I2C_ReadRegister(HT_I2C1, I2C_REGISTER_SR)&0x80000);
	IIC_Start();
	Write_IIC_Byte(0x78);            //Slave address,SA0=0
	Write_IIC_Byte(0x00);			//write command
	Write_IIC_Byte(IIC_Command);
	IIC_Stop();
}
/*********************OLED ��������************************************/
void OLED_Set_Pos(unsigned char x, unsigned char y) 
{ 
	OLED_WrCmd(0xb0+y);
	OLED_WrCmd(((x&0xf0)>>4)|0x10);
	OLED_WrCmd((x&0x0f)|0x00);
} 
/*********************OLEDȫ��************************************/
void OLED_Fill(unsigned char bmp_dat) 
{
	unsigned char y,x;
	for(y=0;y<8;y++)
	{
		OLED_WrCmd(0xb0+y);
		OLED_WrCmd(0x00);
		OLED_WrCmd(0x10);
		for(x=0;x<128;x++)
		OLED_WrDat(bmp_dat);
	}
}

/*********************OLED��ʼ��************************************/
void OLED_Init(void)
{
	delay_us(500);//��ʼ��֮ǰ����ʱ����Ҫ��
	OLED_WrCmd(0xae);//--turn off oled panel
	OLED_WrCmd(0x00);//---set low column address
	OLED_WrCmd(0x10);//---set high column address
	OLED_WrCmd(0x40);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	OLED_WrCmd(0x81);//--set contrast control register
	OLED_WrCmd(0x00); // Set SEG Output Current Brightness
	OLED_WrCmd(0xa1);//--Set SEG/Column Mapping     0xa0���ҷ��� 0xa1����
	OLED_WrCmd(0xc8);//Set COM/Row Scan Direction   0xc0���·��� 0xc8����
	OLED_WrCmd(0xa6);//--set normal display
	OLED_WrCmd(0xa8);//--set multiplex ratio(1 to 64)
	OLED_WrCmd(0x3f);//--1/64 duty
	OLED_WrCmd(0xd3);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	OLED_WrCmd(0x00);//-not offset
	OLED_WrCmd(0xd5);//--set display clock divide ratio/oscillator frequency
	OLED_WrCmd(0x80);//--set divide ratio, Set Clock as 100 Frames/Sec
	OLED_WrCmd(0xd9);//--set pre-charge period
	OLED_WrCmd(0xf1);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
	OLED_WrCmd(0xda);//--set com pins hardware configuration
	OLED_WrCmd(0x12);
	OLED_WrCmd(0xdb);//--set vcomh
	OLED_WrCmd(0x40);//Set VCOM Deselect Level
	OLED_WrCmd(0x20);//-Set Page Addressing Mode (0x00/0x01/0x02)
	OLED_WrCmd(0x02);//
	OLED_WrCmd(0x8d);//--set Charge Pump enable/disable
	OLED_WrCmd(0x14);//--set(0x10) disable
	OLED_WrCmd(0xa4);// Disable Entire Display On (0xa4/0xa5)
	OLED_WrCmd(0xa6);// Disable Inverse Display On (0xa6/a7) 
	OLED_WrCmd(0xaf);//--turn on oled panel
	OLED_Fill(0x00); //��ʼ����
	OLED_Set_Pos(0,0);
} 

void Draw_FullPic(unsigned char BMP[])
{
	unsigned int j=0;
	unsigned char x,y;
	for(y=0;y<8;y++)
	{
		OLED_Set_Pos(0,y);
    for(x=0;x<128;x++)
	    {      
	    	OLED_WrDat(BMP[j++]);
	    }
	}
}
//��ָ��λ�û���
void OLED_DrawPixel(uint8_t x, uint8_t y)
{
	if(y >= 64)
		y=63;
	if(x==0)
		x=1;
	OLEDBuff[(y/8)*WIDTH-1 + x] |=  ((1<<y%8));
}

int8_t _abs(int8_t x)
{
	if(x>=0) x = x;
	else if(x<0) x = -x;
	return x;
}
void draw_line(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
	int8_t dx, dy, ystep;
	int err;
	uint8_t swapxy = 0;

	if (x0 > WIDTH - 1)
			x0 = WIDTH - 1;

	if (y0 > HEIGHT - 1)
			y0 = HEIGHT - 1;

	if (x1 > WIDTH - 1)
			x1 = WIDTH - 1;

	if (y1 > HEIGHT - 1)
			y1 = HEIGHT - 1;

	dx = _abs(x1 - x0);
	dy = _abs(y1 - y0);

	if (dy > dx)
	{
			swapxy = 1;
			_swap_char(dx, dy);
			_swap_char(x0, y0);
			_swap_char(x1, y1);
	}

	if (x0 > x1)
	{
			_swap_char(x0, x1);
			_swap_char(y0, y1);
	}

	err = dx >> 1;

	if (y0 < y1)
	{
			ystep = 1;
	}
	else
	{
			ystep = -1;
	}

	for (; x0 <= x1; x0++)
	{
			if (swapxy == 0)
					OLED_DrawPixel(x0, y0);
			else
					OLED_DrawPixel(y0, x0);

			err -= dy;

			if (err < 0)
			{
					y0 += ystep;
					err += dx;
			}
	}
}
void Draw_Circle(uint8_t x, uint8_t y, uint8_t r)
{
	uint8_t XCurrent = 0, YCurrent = r;
  int16_t Esp = 3 - (r << 1 );
	if(y+r>64)
		return;
	while (XCurrent <= YCurrent ) 
	{
		OLED_DrawPixel(x + XCurrent, y + YCurrent);//1
		OLED_DrawPixel(x - XCurrent, y + YCurrent);//2
		OLED_DrawPixel(x - YCurrent, y + XCurrent);//3
		OLED_DrawPixel(x - YCurrent, y - XCurrent);//4
		OLED_DrawPixel(x - XCurrent, y - YCurrent);//5
		OLED_DrawPixel(x + XCurrent, y - YCurrent);//6
		OLED_DrawPixel(x + YCurrent, y - XCurrent);//7
		OLED_DrawPixel(x + YCurrent, y + XCurrent);//0

		if(Esp < 0 )
			Esp += 4 * XCurrent + 6;
		else 
		{
			Esp += 10 + 4 * (XCurrent - YCurrent );
			YCurrent --;
		}
		XCurrent ++;
  }
}
//x0y0 x1y1ΪͼƬ���ϽǺ����½ǵ�����
void Draw_Pic(unsigned char x0, uint8_t y0,uint8_t x1, uint8_t y1,const unsigned char pic[])
{
	unsigned int j=0;
	unsigned char x,y;

  if(y1%8==0) y=y1/8;      
  else y=y1/8+1;
	for(y=y0;y<y1;y++)
    for(x=x0;x<x1;x++)
			OLEDBuff[x+y*128-1] = pic[j++];
}
void Clear_Buff()
{
	uint16_t i;
	for(i=0;i<WIDTH*PAGES;i++)
		OLEDBuff[i] = 0xff;
}
void Draw_Clock(uint8_t x,uint8_t y,uint8_t r,float _angle)
{
	uint8_t x0,y0;
	x0 = (r-5)*cos(_angle)+x;					//�����ʱ������ĩ�˵�x����
	y0 = (r-5)*sin(_angle)+y;					//y����
	draw_line(x, y, x0, y0);					//��Բ�ĺ�����ĩ��������
	Draw_Circle(x,y,r);								//��Բ
	
}
